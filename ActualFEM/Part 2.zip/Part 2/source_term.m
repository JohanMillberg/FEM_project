function f = source_term(x,y)
f = 8.*pi^2.*sin(2.*pi.*x).*sin(2.*pi.*y);